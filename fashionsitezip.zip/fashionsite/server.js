const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const path = require('path');
const Product = require('./models/product');
const User=require('./models/user');
const authRoutes = require('./routes/auth');
const app = express();
const jwt = require('jsonwebtoken');
const Order=require('./models/order')

// Middleware
const JWT_SECRET = 'fba6cbfb5401ab65c770f026930783cc3ea51581ee8ea21d27b7cb13f0568e36';

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Routes
app.use('/auth', authRoutes);

app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        const user = await User.findOne({ email });
        if (user && user.password === password) {
            // Generate JWT token
            const token = jwt.sign(
                { userId: user._id, role: user.role },
                JWT_SECRET,
                { expiresIn: '1h' } // Token expires in 1 hour
            );

            res.json({ token });
        } else {
            return res.status(401).json({ message: 'Invalid credentials' });
        }
    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
});

app.get('/index.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/index.html'));
});

app.get('/auth/profile', async (req, res) => {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) {
        return res.status(401).json({ error: 'No token provided' });
    }

    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        const user = await User.findById(decoded.userId);
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        return res.json({
            name: user.name,
            email: user.email,
            address: user.address,
            userId:user._id,
            phone:user.phone
        });
    } catch (err) {
        return res.status(500).json({ error: 'Invalid token or database error' });
    }
});

app.post('/api/orders', async (req, res) => {
    const { products, totalPrice, address, fullName } = req.body;
    const token = req.headers.authorization?.split(' ')[1]; // Get the token from the headers

    if (!token) {
        return res.status(401).json({ message: 'No token provided' });
    }

    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        const userId = decoded.userId; // Extract userId from token

        // Create the order object
        const order = new Order({
            userId, // Include userId here
            products,
            totalPrice,
            address,
            fullName
            
        });

        // Save the order
        const savedOrder = await order.save();

        // Update product quantities
        for (const item of products) {
            await Product.findByIdAndUpdate(item.id, { $inc: { quantity: -item.quantity } });
        }

        return res.status(201).json({ message: 'Order placed successfully', order: savedOrder });
    } catch (error) {
        console.error('Error creating order:', error);
        return res.status(500).json({ message: 'Error placing order' });
    }
});

 
app.get('/auth/profile', async (req, res) => {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) {
        return res.status(401).json({ error: 'No token provided' });
    }

    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        const user = await User.findById(decoded.userId);
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        return res.json({
            name: user.name,
            email: user.email,
            address: user.address,
            userId:user._id,
        });
    } catch (err) {
        return res.status(500).json({ error: 'Invalid token or database error' });
    }
});
// Handle logout
app.get('/logout', (req, res) => {
    res.json({ message: 'Logged out successfully' });
});

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/loginSignup', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});


// Route to add a product
app.post('/products', async (req, res) => {
    const { name, description, price, quantity, category, image, variants } = req.body;
    const product = new Product({ name, description, price, quantity, category, image, variants });
    try {
        await product.save();
        res.status(201).json(product);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Route to get all products
app.get('/products', async (req, res) => {
    try {
        const products = await Product.find();
        res.status(200).json(products);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Route to update a product by ID
app.put('/products/:id', async (req, res) => {
    const { id } = req.params;
    const { name, description, price, quantity, category, image, variants } = req.body;
    try {
        const product = await Product.findByIdAndUpdate(
            id,
            { name, description, price, quantity, category, image, variants },
            { new: true } // Return the updated document
        );
        if (!product) {
            return res.status(404).json({ message: 'Product not found' });
        }
        res.status(200).json(product);
    } catch (error) {
        res.status(400).json({ message: error.message });
    }
});

// Route to get a product by ID
app.get('/products/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const product = await Product.findById(id);
        if (!product) {
            return res.status(404).json({ message: 'Product not found' });
        }
        res.status(200).json(product);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Route to delete a product by ID
app.delete('/products/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const product = await Product.findByIdAndDelete(id);
        if (!product) {
            return res.status(404).json({ message: 'Product not found' });
        }
        res.status(200).json({ message: 'Product deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

app.get('/products/category/:category', async (req, res) => {
    const { category } = req.params;
    try {
        const products = await Product.find({ category: category });
        res.status(200).json(products);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

app.get('/tshirt', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'tshirt.html'));
});




// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});