
/* code for dROPDOWN menu  */
document.querySelector('.menu-icon').addEventListener('click', function() {
    const dropdownMenu = document.querySelector('.dropdown-menu');
    dropdownMenu.style.display = dropdownMenu.style.display === 'block' ? 'none' : 'block';
});

console.log('script.js is loaded');

// JavaScript to handle size selection
document.querySelectorAll('.size-options .size-box').forEach(function (sizeBox) {
    sizeBox.addEventListener('click', function () {
        // Remove "selected" class from all sizes within the same product
        let sizeOptions = this.closest('.size-options');
        sizeOptions.querySelectorAll('.size-box').forEach(function (box) {
            box.classList.remove('selected');
        });

        // Add "selected" class to the clicked size
        this.classList.add('selected');

        // Store the selected size for this product
        let selectedSize = this.getAttribute('data-size');
        sizeOptions.setAttribute('data-selected-size', selectedSize);
    });
});

// JavaScript to handle "Add to Cart" button clicks
document.querySelectorAll('.cart-icon').forEach(function (cartButton) {
    cartButton.addEventListener('click', function (event) {
        event.preventDefault();

        // Get product details
        let productId = this.getAttribute('data-product-id');
        let productName = this.getAttribute('data-product-name');
        let productPrice = this.getAttribute('data-product-price');
        let productImage = this.getAttribute('data-product-image');

        // Find the selected size
        let sizeOptions = this.closest('.pro').querySelector('.size-options');
        let selectedSize = sizeOptions.getAttribute('data-selected-size');

        // If no size is selected, show an alert
        if (!selectedSize) {
            alert('Please select a size before adding the product to the cart.');
            return;
        }

        // Create the product object
        let product = {
            id: productId,
            name: productName,
            price: productPrice,
            image: productImage,
            size: selectedSize,
            quantity: 1 // Default quantity
        };

        // Get the cart from localStorage or initialize an empty cart
        let cart = JSON.parse(localStorage.getItem('cart')) || [];

        // Check if the product is already in the cart (with the same size)
        let existingProductIndex = cart.findIndex(
            (item) => item.id === productId && item.size === selectedSize
        );

        if (existingProductIndex !== -1) {
            // If the product already exists, increase its quantity
            cart[existingProductIndex].quantity += 1;
        } else {
            // If it's a new product, add it to the cart
            cart.push(product);
        }

        // Save the updated cart to localStorage
        localStorage.setItem('cart', JSON.stringify(cart));

        // Display a message to the user
        alert('Item added to cart!');

        console.log('Product added to cart:', product);
    });
});

// Function to display cart message
function showCartMessage(message) {
    const cartMessage = document.getElementById('cart-message');
    cartMessage.textContent = message;
    cartMessage.style.display = 'block';
    
    // Hide message after 2 seconds
    setTimeout(() => {
        cartMessage.style.display = 'none';
    }, 2000);
}

// JavaScript to handle search functionality
const searchInput = document.getElementById('search-input');
const suggestionsContainer = document.getElementById('suggestions-container');
const productsContainer = document.querySelector('.pro-container');

// Create a list of product names for autocomplete suggestions
const productNames = Array.from(document.querySelectorAll('.pro .des h5'))
    .map(product => product.textContent.toLowerCase());

// Function to filter products based on the search input
function filterProducts(searchQuery) {
    document.querySelectorAll('.pro').forEach(function (product) {
        const productName = product.querySelector('.des h5').textContent.toLowerCase();
        
        if (productName.includes(searchQuery)) {
            product.style.display = 'block';
        } else {
            product.style.display = 'none';
        }
    });
}

// Function to show suggestions based on the search input
function showSuggestions(searchQuery) {
    // Clear previous suggestions
    suggestionsContainer.innerHTML = '';

    if (searchQuery.length === 0) {
        suggestionsContainer.style.display = 'none';
        return;
    }

    // Filter product names based on the search query
    const filteredNames = productNames.filter(name => name.includes(searchQuery));
    
    // Create and display suggestion items
    filteredNames.forEach(name => {
        const suggestionItem = document.createElement('div');
        suggestionItem.classList.add('suggestion-item');
        suggestionItem.textContent = name;
        suggestionItem.addEventListener('click', function () {
            searchInput.value = name;
            filterProducts(name);
            suggestionsContainer.style.display = 'none';
        });
        suggestionsContainer.appendChild(suggestionItem);
    });

    suggestionsContainer.style.display = filteredNames.length > 0 ? 'block' : 'none';
}

// Event listener for the search input
searchInput.addEventListener('input', function () {
    const searchQuery = this.value.toLowerCase();
    filterProducts(searchQuery);
    showSuggestions(searchQuery);
});

// Close suggestions when clicking outside
document.addEventListener('click', function (event) {
    if (!suggestionsContainer.contains(event.target) && event.target !== searchInput) {
        suggestionsContainer.style.display = 'none';
    }
});
