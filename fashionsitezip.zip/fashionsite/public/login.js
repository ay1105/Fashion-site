document.addEventListener("DOMContentLoaded", function() {
    const loginForm = document.getElementById("login-form");
    const signupForm = document.getElementById("signup-form");
    const loginBtn = document.getElementById("login-btn");
    const signupBtn = document.getElementById("signup-btn");
    const toSignup = document.getElementById("to-signup");
    const toLogin = document.getElementById("to-login");
    const forgotPasswordForm = document.getElementById("forgot-password-form");

    if (loginBtn && signupBtn) {
        // Only add event listeners if the elements are present
        loginBtn.addEventListener("click", () => {
            loginForm.classList.add("active");
            signupForm.classList.remove("active");
        });

        signupBtn.addEventListener("click", () => {
            signupForm.classList.add("active");
            loginForm.classList.remove("active");
        });

        toSignup.addEventListener("click", () => {
            signupForm.classList.add("active");
            loginForm.classList.remove("active");
        });

        toLogin.addEventListener("click", () => {
            loginForm.classList.add("active");
            signupForm.classList.remove("active");
        });
    }

    if (forgotPasswordForm) {
        forgotPasswordForm.addEventListener("submit", (e) => {
            e.preventDefault();
            // Implement your forgot password logic here, such as sending a request to the server
            alert('A password reset link has been sent to your email.');
        });
    }
});
