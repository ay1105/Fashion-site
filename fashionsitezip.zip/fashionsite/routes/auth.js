const express = require('express');
const router = express.Router();
const User = require('../models/user');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

// Secret key for JWT
const JWT_SECRET = 'fba6cbfb5401ab65c770f026930783cc3ea51581ee8ea21d27b7cb13f0568e36';

// Signup Endpoint
router.post('/signup', async (req, res) => {
    const { name, email, password, phone, address } = req.body;
    console.log(req.body);

    try {
        // Hash the password
        const hashedPassword = await bcrypt.hash(password, 10);

        const newUser = new User({
            name,
            email,
            password: hashedPassword,
            phone,
            address
        });

        await newUser.save();
        res.redirect('/login.html');
    } catch (error) {
        console.error(error);
        res.status(500).send('An error occurred during signup');
    }
});


// Login Endpoint
router.post('/login', async (req, res) => {
    const { email, password } = req.body;

    try {
        // Check if the user exists
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(401).send('Invalid email or password');  // Email not found
        }

        // Check if the password matches
        const isPasswordValid = await bcrypt.compare(password, user.password);
        if (!isPasswordValid) {
            return res.status(401).send('Invalid email or password');  // Incorrect password
        }

        // Create JWT token with user ID and role
        const token = jwt.sign(
            { userId: user._id, role: user.role },  // Include user ID and role in JWT payload
            JWT_SECRET,
            { expiresIn: '1h' }
        );

        // Respond with the token (and optionally user data)
        res.json({ message: 'Login successful', token });

    } catch (error) {
        console.error('Login error:', error);
        res.status(500).send('An error occurred during login');
    }
});

module.exports = router;
